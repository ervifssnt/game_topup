# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Context

Laravel 12 game top-up web application developed as cybersecurity coursework. The application implements comprehensive OWASP security best practices including 2FA, token-based password reset, audit logging, and rate limiting.

**Key Security Note**: This is a security-focused project. Never disable or weaken security features (CSP headers, CSRF protection, rate limiting, etc.). All changes must maintain or enhance security posture.

## Common Development Commands

### Docker Environment (Primary)
```bash
# Initial setup
./docker-setup.sh  # Automated setup: builds containers, installs deps, migrates DB

# Container management
docker compose up -d                    # Start all services
docker compose down                     # Stop all services
docker compose exec app sh              # Access app container shell
docker compose logs -f app              # View app logs

# Run Laravel commands in Docker
docker compose exec app php artisan migrate
docker compose exec app php artisan test
docker compose exec app php artisan optimize:clear
docker compose exec app composer install
docker compose exec app php artisan pint  # Code style fixer

# Fix permissions (if storage/cache errors occur)
docker compose exec app chown -R www-data:www-data storage bootstrap/cache
docker compose exec app chmod -R 775 storage bootstrap/cache
```

### Local Development (Alternative)
```bash
# Initial setup
composer install && npm install
cp .env.example .env
php artisan key:generate
touch database/database.sqlite
php artisan migrate:fresh --seed

# Development server
php artisan serve                    # Start on port 8000
npm run dev                          # Start Vite dev server (separate terminal)

# All-in-one development mode (server + queue + logs + vite)
composer dev                         # Runs all services with concurrently

# Testing & maintenance
php artisan test                     # Run all tests
php artisan test --filter=TestName   # Run specific test
composer test                        # Clear config + run tests
./vendor/bin/pint                    # Check/fix code style
php artisan optimize:clear           # Clear all caches
php artisan migrate:fresh --seed     # Fresh DB with test data
php artisan pail                     # Tail logs in real-time
php artisan tinker                   # Interactive REPL

# Frontend build
npm run build                        # Build assets for production
```

## Architecture Overview

### Request Flow & Security Layers

```
Request → Nginx (Docker) → PHP-FPM
  ↓
Middleware Stack:
  1. ForceHttps (redirects HTTP → HTTPS)
  2. SecurityHeaders (CSP, X-Frame-Options, etc.)
  3. StartSession (database-backed sessions)
  4. VerifyCsrfToken (validates @csrf tokens)
  5. SessionTimeout (auto-logout after 30min inactivity)
  6. auth (Laravel authentication)
  7. is_admin (custom admin role check)
  8. throttle (rate limiting)
  ↓
Controller → Form Request Validation → InputSanitizer → Eloquent ORM → Database
  ↓
Audit Logging (all security events)
```

### Key Architectural Patterns

**1. Monolithic Controller Pattern**
- `AdminController` handles ALL admin operations (games, users, transactions, audit logs)
- Deviates from Laravel convention but keeps admin logic centralized for security review
- When adding admin features: add methods to AdminController, not new controllers

**2. Two-Factor Authentication Flow**
```
Login (username/password)
  → Check 2FA enabled?
    → Yes: Store temp session, redirect to /2fa/verify
    → No: Complete login
  → User enters TOTP code or recovery code
  → Verify via Google2FA library
  → Complete authentication
```

**3. Password Reset (Token-Based, Added Oct 2025)**
```
/forgot-password → Generate token (hashed) → Store in password_reset_tokens → Email link
  → /reset-password/{token} → Validate token (< 60min) → Update password → Delete token
```
**Important**: Old admin-approval system removed. Password resets are now self-service.

**4. Top-Up Request Workflow**
```
User: Select game → Upload payment proof → Create TopupRequest (status: pending)
Admin: Review in /admin/topup-requests → Approve/Reject
If Approved: User balance credited → Transaction created → Status: approved
If Rejected: Status: rejected, reason stored
```

**5. Audit Logging Strategy**
- ALL authentication events logged (login, logout, failed attempts, lockouts)
- ALL administrative actions logged (user edits, deletions, game changes)
- ALL security events logged (2FA changes, password resets, balance changes)
- Log location: `audit_logs` table (query via AuditLog model)
- Retention: Indefinite (consider archival strategy for production)

**6. Input Sanitization Pattern**
```php
// ALWAYS follow this pattern:
1. Form Request validation (rules defined in app/Http/Requests/)
2. InputSanitizer methods (sanitizeString, sanitizeEmail, etc.)
3. Eloquent ORM (prevents SQL injection)
4. Blade {{ }} escaping (prevents XSS)

// Example:
$validated = $request->validated();  // Step 1
$name = InputSanitizer::sanitizeString($validated['name']);  // Step 2
Game::create(['name' => $name]);  // Step 3
// In Blade: {{ $game->name }}  // Step 4
```

### Critical File Locations

**Controllers** (app/Http/Controllers/):
- `AuthController.php`: Login, register, logout, 2FA verification
- `PasswordResetController.php`: Token-based password reset (Oct 2025)
- `TwoFactorController.php`: 2FA setup, disable, recovery codes
- `Admin/AdminController.php`: ALL admin functionality (users, games, transactions, audit logs, topup requests, password reset monitoring)
- `GameController.php`: Public game catalog, search API
- `TransactionController.php`: Checkout, payment processing, receipts
- `TopupController.php`: User top-up requests, history
- `ProfileController.php`: User profile, transaction history

**Security Middleware** (app/Http/Middleware/):
- `SecurityHeaders.php`: CSP, X-Frame-Options, X-XSS-Protection, etc.
- `ForceHttps.php`: Redirects HTTP → HTTPS (production)
- `IsAdmin.php`: Checks `is_admin` flag, aborts with 403 if false
- `SessionTimeout.php`: Logs out after 30min inactivity (checks `last_activity` in session)

**Models** (app/Models/):
- `User.php`: 2FA fields (two_factor_secret, two_factor_recovery_codes, two_factor_enabled), lockout fields (locked_until)
- `Game.php`: hasMany TopupOption
- `TopupOption.php`: belongsTo Game, pricing for game items
- `TopupRequest.php`: User requests for balance top-up (pending/approved/rejected)
- `Transaction.php`: All balance changes (topup/purchase/refund)
- `AuditLog.php`: Security event logging

**Configuration** (config/):
- `google2fa.php`: TOTP window (30s), secret length (32 chars)
- `hashing.php`: Bcrypt rounds (12)
- `session.php`: Database driver, 120min lifetime, secure cookies
- `auth.php`: Guards, providers, password reset settings

**Helpers** (app/Helpers/):
- `InputSanitizer.php`: All sanitization functions (auto-loaded via composer.json)
  - Methods: sanitizeString, sanitizeEmail, sanitizeUrl, sanitizePhone, sanitizeUsername, sanitizeNumeric

### Route Organization (routes/web.php)

**CRITICAL**: Wildcard route `/topup/{id}` is at the END to avoid catching specific routes like `/topup/request`. Always add new specific routes BEFORE wildcards.

```php
// Order matters! Specific routes first:
Route::get('/topup/request', ...)   // ← Must be before wildcard
Route::get('/topup/history', ...)   // ← Must be before wildcard
Route::get('/topup/{id}', ...)      // ← Wildcard LAST
```

### Database Schema Highlights

**users**: Standard Laravel + 2FA fields + lockout fields
- `two_factor_secret`, `two_factor_recovery_codes`, `two_factor_enabled`
- `locked_until` (timestamp for 15min lockout)
- `is_admin` (boolean for role check)

**password_reset_tokens**: Laravel standard (email, token, created_at)
- Tokens are hashed (bcrypt) before storage
- 60-minute expiration enforced in controller

**login_attempts**: Tracks failed logins (email, ip_address, attempted_at)
- Reset on successful login
- Triggers account lockout after 5 attempts

**audit_logs**: Security event logging (user_id, action, ip_address, user_agent, created_at)
- Actions: user_login, login_failed, password_reset_requested, 2fa_enabled, admin_user_edited, etc.

**topup_requests**: User top-up submissions (user_id, topup_option_id, proof_path, status, admin_notes)
- Status: pending, approved, rejected
- Proof images stored in `storage/app/topup_proofs/`

**sessions**: Database-backed sessions (id, user_id, payload, last_activity)
- 120-minute lifetime, 30-minute idle timeout

### Environment Configuration

**Docker** (uses MySQL):
```env
DB_CONNECTION=mysql
DB_HOST=mysql  # Docker service name
DB_DATABASE=laravel_topup
DB_USERNAME=laravel_user
DB_PASSWORD=secure_password
SESSION_DRIVER=database
QUEUE_CONNECTION=database
```

**Local** (uses SQLite):
```env
DB_CONNECTION=sqlite
SESSION_DRIVER=database
QUEUE_CONNECTION=database
MAIL_MAILER=log  # Emails logged to storage/logs/laravel.log
```

**Critical**: Never commit `.env` files. Always use `.env.example` as template.

## Development Guidelines

### When Adding New Features

**Authentication-related**:
- Add audit log entry for security events
- Apply rate limiting (throttle:5,1 or similar)
- Validate input via Form Request class
- Sanitize with InputSanitizer helper
- Test with 2FA enabled and disabled users

**Admin features**:
- Add to `AdminController` (not new controller)
- Protect with `['auth', 'is_admin']` middleware
- Add audit logging for the action
- Prevent admins from modifying other admins/themselves where appropriate

**User-facing features**:
- Add CSRF token (`@csrf` directive)
- Validate input (Form Request)
- Sanitize output (Blade `{{ }}`)
- Add rate limiting if sensitive
- Log to audit_logs if security-relevant

**Database changes**:
```bash
php artisan make:migration describe_change
# Write up() and down() methods
php artisan migrate
# Test rollback: php artisan migrate:rollback
```

### Testing Changes

```bash
# Run all tests
php artisan test

# Clear caches after config/route changes
php artisan optimize:clear

# Fresh database for clean testing
php artisan migrate:fresh --seed

# Test with Docker
docker compose exec app php artisan test
```

### Code Style

Use Laravel Pint (already configured):
```bash
./vendor/bin/pint --test  # Check issues
./vendor/bin/pint         # Auto-fix
```

### Debugging

```bash
# View logs in real-time
php artisan pail

# Or tail log files
tail -f storage/logs/laravel.log

# Docker logs
docker compose logs -f app

# Database inspection
php artisan tinker
> User::count()
> AuditLog::where('action', 'login_failed')->get()
```

## Security Reminders

**Input Handling**:
- Always validate (Form Request) → sanitize (InputSanitizer) → escape (Blade `{{ }}`)
- Never use raw SQL (`DB::select("... $var ...")`) - use Eloquent or query builder
- Never use `{!! !!}` unless HTML is explicitly trusted and sanitized

**Password Handling**:
- Always use `Hash::make()` - never store plaintext
- Bcrypt rounds: 12 (configured in config/hashing.php)
- Never log passwords
- Never email passwords

**Session Security**:
- Sessions are database-backed (sessions table)
- Cookies: HttpOnly, Secure, SameSite=Lax
- 30-minute idle timeout enforced by SessionTimeout middleware
- Session regeneration on login (prevents session fixation)

**Rate Limiting**:
- Login: 5/min (`throttle:5,1`)
- Password reset: 5/min
- Top-up request: 5/min
- API search: 60/min
- Registration: 60/min

**Audit Logging Requirements**:
```php
// Template for security-sensitive actions:
AuditLog::create([
    'user_id' => auth()->id() ?? null,
    'action' => 'descriptive_action_name',
    'ip_address' => request()->ip(),
    'user_agent' => request()->userAgent(),
]);
```

**CSRF Protection**:
- All POST/PUT/DELETE forms MUST have `@csrf` directive
- VerifyCsrfToken middleware validates all non-GET requests
- Exempt routes only if absolutely necessary (e.g., webhooks)

## Known Limitations & TODOs

**Email**: Using `log` mailer - emails written to `storage/logs/laravel.log`
- For production: Configure SMTP in `.env`

**Tests**: Minimal coverage (2 example tests only)
- TODO: Feature tests for all controllers
- TODO: Unit tests for InputSanitizer, models

**Promo Codes**: Tables exist (`promo_codes`, `promo_code_usage`) but feature not implemented
- TODO: Controller, views, validation logic

**File Uploads**: Basic validation, local storage only
- TODO: Add file size limits
- TODO: Consider S3 for production

**Search**: Basic LIKE queries
- TODO: Consider Laravel Scout for full-text search

## Recent Changes (October-November 2025)

**Password Reset System Overhaul**:
- **Removed**: Admin-approved password reset requests
- **Removed**: `password_reset_requests` table
- **Added**: Token-based self-service password reset (Laravel standard)
- **Added**: `/admin/password-reset-activity` monitoring page
- **Migration**: `2025_10_23_155526_drop_password_reset_requests_table.php`

**Key Files**:
- `app/Http/Controllers/PasswordResetController.php` (NEW)
- `resources/views/auth/forgot-password.blade.php` (NEW)
- `resources/views/auth/reset-password.blade.php` (NEW)
- `resources/views/admin/password-reset-activity.blade.php` (NEW)

## Production Deployment Notes

**Before deploying**:
1. Change all default credentials (admin@example.com, database passwords)
2. Set `APP_ENV=production`, `APP_DEBUG=false`
3. Generate new `APP_KEY`
4. Configure real SMTP mailer (MAIL_* variables)
5. Enable ForceHttps middleware (verify in bootstrap/app.php)
6. Review and tighten CSP headers (SecurityHeaders middleware)
7. Consider file storage migration (local → S3)
8. Set up log rotation for audit_logs table
9. Test all rate limits under production load
10. Review all TODO comments in codebase

**Docker production**:
```bash
docker compose build --build-arg BUILD_TARGET=production
docker compose up -d
```

## Default Credentials (Development Only)

**Admin**: admin@example.com / password123
**User**: user@example.com / password123
**DB** (Docker): laravel_user / secure_password
**phpMyAdmin**: http://localhost:8080

**Port Configuration**:
- App: 8000
- MySQL: 3306
- phpMyAdmin: 8080

## Additional Documentation

- **README.md**: Quick start guide
- **PENTEST_REPORT.md**: Security assessment results (October 2025)
- **TESTING_SUMMARY.md**: Password reset test results
- **DOCKER-SECURITY.md**: Docker security review notes
